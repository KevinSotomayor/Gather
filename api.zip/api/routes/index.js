//obtenemos los modelos con todas sus funcionalidades
var UserModel = require('../models/users');
var PotModel = require('../models/pot');
 
//creamos el ruteo de la aplicación
module.exports = function(app)
{
    
 
    //obtiene los datos del bote
    app.get("/pot/:id", function(req,res)
    {
        //id del bote
        var id = req.params.id;
        
            PotModel.getPot(id,function(error, data)
            {
               
                    res.json(200,data);
              
            });
        
    });

     //obtiene los donantes del bote
    app.get("/donors/:id", function(req,res)
    {
        //id del bote
        var id = req.params.id;
        //solo buscamos si la id es un número
        if(!isNaN(id))
        {
            PotModel.getDonor(id,function(error, data)
            {
               
                    res.json(200,data);
              
            });
        }
        //si hay algún error
        else
        {
            res.json(500,{"msg":"0"});
        }
    });

     //obtiene las donaciones hechas por un usuario
    app.get("/donations/:id", function(req,res)
    {
        //id del bote
        var id = req.params.id;
        //solo buscamos si la id es un número
        if(!isNaN(id))
        {
            PotModel.getDonations(id,function(error, data)
            {
               
                    res.json(200,data);
              
            });
        }
        //si hay algún error
        else
        {
            res.json(500,{"msg":"0"});
        }
    });
 
    //Inserta un usuario nuevo
    app.post("/signup", function(req,res)
    {
        //creamos un objeto con los datos a insertar del usuario
        var userData = {            
            NAME : req.body.name,
            EMAIL : req.body.email,
            SURNAME : req.body.surname,
            PASSWORD : req.body.password,
            IBAN : req.body.iban,
            DNI  : req.body.dni          
        };
        UserModel.insertUser(userData,function(error, data)
        {
            
              res.json(200,data);
        });
    });

      //Login
    app.post("/login", function(req,res)
    {
        //creamos un objeto con los datos del usuario
        var userData = { 
            EMAIL : req.body.email,         
            PASSWORD : req.body.password                   
        };
        UserModel.loginUser(userData,function(error, data)
        {
            
              res.json(200,data);
        });
    });
 
  
   //Inserta un bote
    app.post("/newPot", function(req,res)
    {
        //creamos un objeto con los datos a insertar del bote
        var userData = {
            
            POT_NAME : req.body.pot_name,
            POT_CONCEPT : req.body.pot_concept,
            POT_IMAGE : req.body.pot_image,           
            OWNER : req.body.owner                    
        };
        PotModel.insertPot(userData,function(error, data)
        {
            
              res.json(200,data);
        });
    });



   //Inserta una transacción nueva
    app.post("/transaction", function(req,res)
    {
        //creamos un objeto con los datos a insertar de la transacción
        var userData = {            
            MONEY : req.body.money,
            CONCEPT : req.body.concept,
            DONOR : req.body.user_id,           
            POT_ID : req.body.pot_id                    
        };

        PotModel.insertDonor(userData,function(error, data)
        {
            
              res.json(200,data);
        });
    });


}