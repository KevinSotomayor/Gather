//llamamos al paquete mysql que hemos instalado
var mysql = require('mysql'),
//creamos la conexion a nuestra base de datos con los datos de acceso de cada uno
/*connection = mysql.createConnection(
    {
        host: 'localhost',
        user: 'root',  
        password: '',
        database: 'hacathon'
    }
);

*/

connection = mysql.createConnection(
    {
        host: 'localhost',
        user: 'finapppaty',  
        password: 'jupy6anev',
        database: 'zadmin_finappparty'
    }
);
 
 
//creamos un objeto para ir almacenando todo lo que necesitemos
var userModel = {};
 

 
//Obtenemos la información del bote
userModel.getPot = function(id,callback)
{
    if (connection)
    {
        if(!isNaN(id)){
        var sql='SELECT POT.POT_NAME, USER.NAME, USER.SURNAME, POT.POT_CONCEPT,POT.POT_ID, USER.IBAN,SUM(TRANSACTION.MONEY) AS TOTAL,POT.POT_IMAGE FROM POT, USER,TRANSACTION WHERE POT.OWNER = USER.USER_ID AND USER.USER_ID ='+connection.escape(id)+' AND POT.POT_ID=TRANSACTION.POT_ID GROUP BY POT.POT_ID';
        
        }
        else{
         var sql='SELECT POT.POT_NAME, USER.NAME, USER.SURNAME, POT.POT_CONCEPT,POT.POT_ID, USER.IBAN,SUM(TRANSACTION.MONEY) AS TOTAL,POT.POT_IMAGE FROM POT, USER,TRANSACTION WHERE POT.OWNER = USER.USER_ID AND USER.EMAIL LIKE '+connection.escape(id)+' AND POT.POT_ID=TRANSACTION.POT_ID GROUP BY POT.POT_ID';
 
        }
        connection.query(sql, function(error, row)
        {
            if(error)
            {
               callback(null,{"msg:" : 0});
            }
            else
            {
                callback(null, row);
            }
        });
    }
}

//Obtenemos los donantes de un bote
userModel.getDonor = function(id,callback)
{
    if (connection)
    {

        var sql='SELECT USER.NAME, USER.SURNAME, TRANSACTION.MONEY FROM TRANSACTION, USER WHERE TRANSACTION.DONOR=USER.USER_ID AND TRANSACTION.POT_ID='+connection.escape(id);
        connection.query(sql, function(error, row)
        {
            if(error)
            {
               callback(null,{"msg:" : 0});
            }
            else
            {
                callback(null, row);
            }
        });
    }
}


//Obtenemos las donaciones de un usuario
userModel.getDonations = function(id,callback)
{
    if (connection)
    {

        var sql='SELECT TRANSACTION.MONEY, POT.POT_NAME, TRANSACTION.CONCEPT FROM POT, TRANSACTION WHERE POT.POT_ID = TRANSACTION.POT_ID AND TRANSACTION.DONOR='+connection.escape(id);
        console.log(sql);
        connection.query(sql, function(error, row)
        {
            if(error)
            {
               callback(null,{"msg:" : 0});
            }
            else
            {
                callback(null, row);
            }
        });
    }
}


//añadir un nuevo bote
userModel.insertDonor = function(userData,callback)
{
    if (connection)
    {
        connection.query('INSERT INTO TRANSACTION SET ?', userData, function(error, result)
        {
            if(error)
            {
              callback(null,{"msg:" : 0});
            }
            else
            {
                
              callback(null,{"msg:" : 1});
            }
        });
    }
}

 
//añadir un nuevo bote
userModel.insertPot = function(userData,callback)
{
    if (connection)
    {
        connection.query('INSERT INTO POT SET ?', userData, function(error, result)
        {
            if(error)
            {
              callback(null,{"msg:" : 0});
            }
            else
            {
                
              callback(null,{"msg:" : 1});
            }
        });
    }
}
 
 
//exportamos el objeto para tenerlo disponible en la zona de rutas
module.exports = userModel;