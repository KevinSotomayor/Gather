//llamamos al paquete mysql que hemos instalado
var mysql = require('mysql'),
//creamos la conexion a nuestra base de datos con los datos de acceso de cada uno
/*
connection = mysql.createConnection(
    {
        host: 'localhost',
        user: 'root',  
        password: '',
        database: 'hacathon'
    }
);
*/

connection = mysql.createConnection(
    {
        host: 'localhost',
        user: 'finapppaty',  
        password: 'jupy6anev',
        database: 'zadmin_finappparty'
    }
);

 
//creamos un objeto para ir almacenando todo lo que necesitemos
var userModel = {};
 
//Login del usuario
userModel.loginUser = function(userData,callback)
{
    if (connection)
    {
        var sql = 'SELECT USER.USER_ID FROM USER WHERE USER.EMAIL LIKE ' + connection.escape(userData.EMAIL) + ' AND ' +  
        'USER.PASSWORD LIKE ' + connection.escape(userData.PASSWORD) +
        ';';
        
        connection.query(sql, function(error, result)
        {
            
            if((error)||(result==""))
            {
              callback(null,{"msg:" : 0});
            }
            else
            {
                
              callback(null,{"msg:" : 1});
            }
        });
    }
}

 

//Añadir un nuevo usuario
userModel.insertUser = function(userData,callback)
{
    if (connection) 
    {
            //Comprobamos que el correo electrónico no está registrado ya
        var sqlExist='SELECT USER.USER_ID FROM USER WHERE USER.EMAIL LIKE ' +connection.escape(userData.EMAIL);

        connection.query(sqlExist, function(err, rows, fields) 
        {
            
              
            //Si no existe el correo insertamos el nuevo usuario
       if(!rows[0]){
var sql='INSERT INTO USER SET ?';
           
        connection.query(sql,userData, function(error, row) 
        {     //Si hay alguna error al registrar el usuario devuelvo 0
            if(error)
            {
                
              callback(null,{"msg:" : 0});
            }
            else
            {
                //Si el usuario se registra correctamente devuelvo 1
              callback(null,{"msg:" : 1});
            }
        });
            
            }else {
                //Si el usuario ya está registrado devuelvo -1
                 callback(null,{"msg:" : -1});
            }
        
            
});
    }
}



 
//exportamos el objeto para tenerlo disponible en la zona de rutas
module.exports = userModel;