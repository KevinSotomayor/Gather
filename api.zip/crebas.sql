/*==============================================================*/
/* DBMS name:      TEAM41                                       */
/* Created on:     24/10/2014 19:47:19                          */
/*==============================================================*/

/*==============================================================*/
/* Table: POT                                                   */
/*==============================================================*/
create table POT 
(
   POT_ID                   integer                    not null auto_increment,
   POT_NAME             long varchar                   not null,
   POT_CONCEPT          long varchar                   not null,
   POT_IMAGE            long varchar                       null,
   OWNER                integer                       not null,
   constraint PK_POT primary key clustered (POT_ID)
);

/*==============================================================*/
/* Table: TRANSACTION                                           */
/*==============================================================*/
create table TRANSACTION 
(
   TRANSACTION_ID       integer                        not null auto_increment,
   MONEY                numeric(65,2)                not null,
   CONCEPT              long varchar                   null,
   DONOR                integer                   not null,
   POT_ID               integer                    not null,
   constraint PK_TRANSACTION primary key clustered (TRANSACTION_ID)
);

/*==============================================================*/
/* Table: "USER"                                                */
/*==============================================================*/
create table USER
(
   EMAIL                long varchar                   not null,   
   USER_ID              integer                        not null auto_increment,
   NAME                 long varchar                  not null,
   SURNAME              long varchar                  not null,
   DNI                  long varchar                   null,
   PASSWORD             varchar(50)                   not null,
   IBAN                 long varchar                  not null,
   constraint PK_USER primary key clustered (USER_ID)
);

ALTER TABLE TRANSACTION
ADD FOREIGN KEY (DONOR)
REFERENCES USER(USER_ID);

ALTER TABLE TRANSACTION
ADD FOREIGN KEY (POT_ID)
REFERENCES POT(POT_ID);

ALTER TABLE POT
ADD FOREIGN KEY (OWNER)
REFERENCES USER(USER_ID);

